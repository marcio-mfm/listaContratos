/* Formatar Moeda
function formatarMoeda() {
  var elemento = document.getElementById('validationServer04');
  var valor = elemento.value;
  
  valor = valor + '';
  valor = parseInt(valor.replace(/[\D]+/g,''));
  valor = valor + '';
  valor = valor.replace(/([0-9]{2})$/g, ",$1");

  if (valor.length > 6) {
    valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
  }

  elemento.value = valor;
};*/

/*Funções de Cadastro*/
/*class Cadastro {
  constructor() {
    this.id = 0;
  }

  cadastrar() {
    this.infoContrato()
  }

  infoContrato() {
    let contrato = {}

    

    return contrato;
  }

  limpar() {

  }

}

var Cadastro = new Cadastro()*/



/*Funções para busca*/
class Busca{
  constructor () {
    this.nome= document.getElementById("validationServer01"),
    this.data= document.getElementById("validationServer02"),
    this.contrato= document.getElementById("validationServer03"),
    this.valor= document.getElementById("validationServer04")

  }

  formatarMoeda() {
    var valorFim = this.valor.value;
    
    valorFim = valorFim + '';
    valorFim = parseInt(valorFim.replace(/[\D]+/g,''));
    valorFim = valorFim + '';
    valorFim = valorFim.replace(/([0-9]{2})$/g, ",$1");
  
    if (valorFim.length > 6) {
      valorFim = valorFim.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
  
    this.valor.value = valorFim;
  };

  validaNome(){
    var inputNome = this.nome.value;

    if(inputNome.length < 3 && inputNome.length > 0) {
      this.nome.classList.add("is-invalid");
      this.nome.classList.remove("is-valid");
    } else{
      this.nome.classList.add("is-valid");
      this.nome.classList.remove("is-invalid");
    };
    
  };

  validaData(){
    var inputData = this.data.value;
    var separaData = inputData.split("-");
    var converteData = new Date(separaData[0], separaData[1] - 1, separaData[2]);

    if(converteData > new Date()) {
      this.data.classList.add("is-invalid");
      this.data.classList.remove("is-valid");
    } else{
      this.data.classList.add("is-valid");
      this.data.classList.remove("is-invalid");
    };
    
  };

  validaContrato(){
    var inputContrato = this.contrato.value;

    if(inputContrato.length < 9 && inputContrato.length > 0) {
      this.contrato.classList.add("is-invalid");
      this.contrato.classList.remove("is-valid");
    } else{
      this.contrato.classList.add("is-valid");
      this.contrato.classList.remove("is-invalid");
    };
    
  };

};

let busca = new Busca();

/*Funções para busca*/

class Cadastro{
  constructor () {
    this.nome= document.getElementById("validationServer05"),
    this.data= document.getElementById("validationServer06"),
    this.contrato= document.getElementById("validationServer07"),
    this.valor= document.getElementById("validationServer08")

  }

  formatarMoeda() {
    var valorFim = this.valor.value;
    
    valorFim = valorFim + '';
    valorFim = parseInt(valorFim.replace(/[\D]+/g,''));
    valorFim = valorFim + '';
    valorFim = valorFim.replace(/([0-9]{2})$/g, ",$1");
  
    if (valorFim.length > 6) {
      valorFim = valorFim.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
  
    this.valor.value = valorFim;
  };

  validaNome(){
    var inputNome = this.nome.value;

    if(inputNome.length < 3 && inputNome.length > 0) {
      this.nome.classList.add("is-invalid");
      this.nome.classList.remove("is-valid");
    } else{
      this.nome.classList.add("is-valid");
      this.nome.classList.remove("is-invalid");
    };
    
  };

  validaData(){
    var inputData = this.data.value;
    var separaData = inputData.split("-");
    var converteData = new Date(separaData[0], separaData[1] - 1, separaData[2]);

    if(converteData > new Date()) {
      this.data.classList.add("is-invalid");
      this.data.classList.remove("is-valid");
    } else{
      this.data.classList.add("is-valid");
      this.data.classList.remove("is-invalid");
    };
    
  };

  validaContrato(){
    var inputContrato = this.contrato.value;

    if(inputContrato.length < 9 && inputContrato.length > 0) {
      this.contrato.classList.add("is-invalid");
      this.contrato.classList.remove("is-valid");
    } else{
      this.contrato.classList.add("is-valid");
      this.contrato.classList.remove("is-invalid");
    };
    
  };

};

let cadastro = new Cadastro();

    /*Evitar envio com dado inválido*/
    function validaEnvio()  {
        'use strict';
        window.addEventListener('load', function() {
          // Pega todos os formulários que nós queremos aplicar estilos de validação Bootstrap personalizados.
          var forms = document.getElementsByClassName('needs-validation');
          // Faz um loop neles e evita o envio
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      };
