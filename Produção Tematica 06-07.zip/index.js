/* Formatar Moeda
function formatarMoeda() {
  var elemento = document.getElementById('validationServer04');
  var valor = elemento.value;
  
  valor = valor + '';
  valor = parseInt(valor.replace(/[\D]+/g,''));
  valor = valor + '';
  valor = valor.replace(/([0-9]{2})$/g, ",$1");

  if (valor.length > 6) {
    valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
  }

  elemento.value = valor;
};*/

/*Funções de Cadastro*/
/*class Cadastro {
  constructor() {
    this.id = 0;
  }

  cadastrar() {
    this.infoContrato()
  }

  infoContrato() {
    let contrato = {}

    

    return contrato;
  }

  limpar() {

  }

}

var Cadastro = new Cadastro()*/



/*Funções para busca*/
class Busca{
  constructor () {
    this.nome= document.getElementById("validationServer01"),
    this.data= document.getElementById("validationServer02"),
    this.contrato= document.getElementById("validationServer03"),
    this.valor= document.getElementById("validationServer04")

  }

  formatarMoeda() {
    var valorFim = this.valor.value;
    
    valorFim = valorFim + '';
    valorFim = parseInt(valorFim.replace(/[\D]+/g,''));
    valorFim = valorFim + '';
    valorFim = valorFim.replace(/([0-9]{2})$/g, ",$1");
  
    if (valorFim.length > 6) {
      valorFim = valorFim.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
  
    this.valor.value = valorFim;
  };

  validaNome(){
    var inputNome = this.nome.value;

    if(inputNome.length < 3 && inputNome.length > 0) {
      this.nome.classList.add("is-invalid");
      this.nome.classList.remove("is-valid");
    } else{
      this.nome.classList.add("is-valid");
      this.nome.classList.remove("is-invalid");
    };
    
  };

  validaData(){
    var inputData = this.data.value;
    var separaData = inputData.split("-");
    var converteData = new Date(separaData[0], separaData[1] - 1, separaData[2]);

    if(converteData > new Date()) {
      this.data.classList.add("is-invalid");
      this.data.classList.remove("is-valid");
    } else{
      this.data.classList.add("is-valid");
      this.data.classList.remove("is-invalid");
    };
    
  };

  validaContrato(){
    var inputContrato = this.contrato.value;

    if(inputContrato.length < 9 && inputContrato.length > 0) {
      this.contrato.classList.add("is-invalid");
      this.contrato.classList.remove("is-valid");
    } else{
      this.contrato.classList.add("is-valid");
      this.contrato.classList.remove("is-invalid");
    };
    
  };

};

let busca = new Busca();

/*Funções para Cadastro*/

class Cadastro{
  constructor () {
    this.nome = document.getElementById("validationServer05"),
    this.data = document.getElementById("validationServer06"),
    this.numContrato = document.getElementById("validationServer07"),
    this.valor = document.getElementById("validationServer08"),
    this.tbody = document.getElementById("tbody"),
    this.arrayContrato = []
    this.controle = 0;

  }

  formatarMoeda() {
    var valorFim = this.valor.value;
    
    valorFim = valorFim + '';
    valorFim = parseInt(valorFim.replace(/[\D]+/g,''));
    valorFim = valorFim + '';
    valorFim = valorFim.replace(/([0-9]{2})$/g, ",$1");
  
    if (valorFim.length > 6) {
      valorFim = valorFim.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
  
    this.valor.value = valorFim;
  };

  validaNome(){
    var inputNome = this.nome.value;

    if(inputNome.length < 3 && inputNome.length > 0) {
      this.nome.classList.add("is-invalid");
      this.nome.classList.remove("is-valid");
    } else{
      this.nome.classList.add("is-valid");
      this.nome.classList.remove("is-invalid");
    };
    
  };
  
  validaData(){
    var inputData = this.data.value;
    var separaData = inputData.split("-");
    var converteData = new Date(separaData[0], separaData[1] - 1, separaData[2]);

    if(converteData > new Date()) {
      this.data.classList.add("is-invalid");
      this.data.classList.remove("is-valid");
    } else{
      this.data.classList.add("is-valid");
      this.data.classList.remove("is-invalid");
    };
    
  };

  validaContrato(){
    var inputContrato = this.numContrato.value;

    if(inputContrato.length < 9 && inputContrato.length > 0) {
      this.numContrato.classList.add("is-invalid");
      this.numContrato.classList.remove("is-valid");
    } else{
      this.numContrato.classList.add("is-valid");
      this.numContrato.classList.remove("is-invalid");
    };
    
  };

  validaVazio(contrato){
    let aviso = '';
    if(contrato.nomeCliente == ''){
      aviso += 'Informe o nome do cliente \n';
    }
    if(contrato.dataAss == ''){
      aviso += 'Informe a data de Assinatura \n';
    }
    if(contrato.nContrato == ''){
      aviso += 'Informe o número do contrato \n';
    }
    if(contrato.valorContrato == ''){
      aviso += 'Informe o valor do Contrato \n';
    }
    if(aviso != ''){
      alert(aviso);
      return false;
    };

    return true;

  };
  /*Cadastro dos Contratos*/

  criaArray (){
    let contrato = this.buscaDados();

    if(this.validaVazio(contrato)){
    
      this.incluiContratos(contrato);

    }
    this.listaContrato();
    this.limpaCampos();
    this.controle ++;
  }

  incluiContratos (contrato){
    this.arrayContrato.push(contrato);
  }

  buscaDados (){
    let contrato = {}
    contrato.nomeCliente = this.nome.value;
    contrato.dataAss = this.data.value;
    contrato.nContrato = this.numContrato.value;
    contrato.valorContrato = this.valor.value;

    return contrato;
  }

  limpaCampos(){
    const formulario = document.getElementById("formCadastro");
    formulario.reset();
  };

  listaContrato (){
  
    const trNContrato = document.createElement('tr');
    const tdNContrato = document.createElement('td');
    const textNContrato = document.createTextNode(this.arrayContrato[this.controle].nContrato);

    this.tbody.appendChild(trNContrato);
    trNContrato.appendChild(tdNContrato);
    tdNContrato.appendChild(textNContrato);

    const tdNome = document.createElement('td');
    const textNome = document.createTextNode(this.arrayContrato[this.controle].nomeCliente);
    
    trNContrato.appendChild(tdNome);
    tdNome.appendChild(textNome);

    const tdValor = document.createElement('td');
    const textValor = document.createTextNode('R$ ' + this.arrayContrato[this.controle].valorContrato);
    
    trNContrato.appendChild(tdValor);
    tdValor.appendChild(textValor);

    const tdData = document.createElement('td');
    const textData = this.arrayContrato[this.controle].dataAss;
    const separaTextData = textData.split("-");
    const novoTextData = document.createTextNode(separaTextData[2] + '/' + separaTextData[1] + '/' + separaTextData[0]);

    trNContrato.appendChild(tdData);
    tdData.appendChild(novoTextData);

  };
};

let cadastro = new Cadastro();

    /*Evitar envio com dado inválido*/
    function validaEnvio()  {
        'use strict';
        window.addEventListener('load', function() {
          // Pega todos os formulários que nós queremos aplicar estilos de validação Bootstrap personalizados.
          var forms = document.getElementsByClassName('needs-validation');
          // Faz um loop neles e evita o envio
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      };
